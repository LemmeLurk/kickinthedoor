Flask-WhooshAlchemy extension
=============================

Supports the easy text-indexing of SQLAlchemy model fields using Whoosh.

Docs available at:

http://packages.python.org/Flask-WhooshAlchemy/
